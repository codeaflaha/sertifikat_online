<footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
          
            <ul>
              <li>
                <a href="https://arab-uai.com">
                  Munasba Tim
                </a>
              </li>
              
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i>
           
          </div>
        </div>
      </footer>